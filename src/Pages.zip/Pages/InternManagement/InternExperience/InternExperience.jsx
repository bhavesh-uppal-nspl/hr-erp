import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Grid,
  Paper,
  MenuItem,
  TextField,
  Checkbox,
  CircularProgress,
  InputLabel,
  Select,
  FormHelperText,
  FormControl,
  FormControlLabel,
  Accordion,
  AccordionSummary,
  Typography,
  AccordionDetails,
  FormGroup,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { useNavigate, useParams } from "react-router-dom";
import useAuthStore from "../../../Zustand/Store/useAuthStore";
import { getIndustry } from "../../../Apis/Organization-apis";
import { fetchGeneralCountries } from "../../../Apis/OrganizationLocation";
import useEmployeeDataStore from "../../../Zustand/Store/useEmployeeDataStore";
import useInternDataStore from "../../../Zustand/Store/useInternDataStore";

function InternExperience({ mode, employeeId }) {
  const { id } = useParams();
  const { userData } = useAuthStore();

  const {
    setExperienceData,
    Experience,
    ExperienceErrors,
    addExperience,
    removeExperience,
  } = useInternDataStore();
  const org = userData?.organization;

  const [expanded, setExpanded] = useState("Experience 1");

  const handleChangeAccoridan = (panelId) => (event, isExpanded) => {
    setExpanded(isExpanded ? panelId : "");
  };

  const [countrycode, setCountryCode] = useState("");
  const [Industry, setIndustry] = useState("");

  let navigate = useNavigate();

  useEffect(() => {
    {
      fetchGeneralCountries()
        .then((data) => {
          setCountryCode(data?.countries);
        })
        .catch((err) => {
          console.log(err.message);
        });
    }
  }, []);

  useEffect(() => {
    {
      getIndustry()
        .then((data) => {
          setIndustry(data?.industries);
        })
        .catch((err) => {
          console.log(err.message);
        });
    }
  }, []);

  const handleChange = (e, idx) => {
    const { name, value } = e.target;
    setExperienceData(name, value, idx);
    if (name === "compensation_status" && value === "Unpaid") {
      ["currency_code", "compensation_amount"].forEach((field) =>
        setExperienceData(field, "", idx)
      );
    }
  };
  const handleCheckboxChange = (e, idx) => {
    const { name, checked } = e.target;
    setExperienceData(name, checked, idx);
  };

  return (
    <Box px={4}>
      <Box>
        {Experience?.map((item, id) => ({
          name: `Experience ${id + 1}`,
          mainData: item,
        }))?.map((section, idx) => (
          <Accordion
            sx={{ mb: 2 }}
            key={section.name}
            expanded={expanded === section.name}
            onChange={handleChangeAccoridan(section.name)}
          >
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography
                  variant="h6"
                  sx={{ fontSize: "15px", fontWeight: "bold" }}
                >
                  {section.name}
                </Typography>
                {idx != 0 && (
                  <DeleteOutlineIcon
                    onClick={(e) => {
                      e.stopPropagation();
                      removeExperience(idx);
                    }}
                    sx={{ color: "error.main", ml: 2 }}
                  />
                )}
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              {expanded === section.name && (
                <Grid item xs={12} md={8}>
                  <Paper elevation={4} sx={{ p: 3 }}>
                    <Grid container spacing={2}>


                      <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                  }}
                >

                  
                      <FormControl
                        fullWidth
                        required
                        error={!!ExperienceErrors?.[idx]?.experience_type}
                      
                      >
                        <InputLabel id="experience_type-label">
                          Experience Type
                        </InputLabel>

                        <Select
                          labelId="experience_type-label"
                          id="experience_type"
                          name="experience_type"
                            disabled={mode ==="view"}
                          value={section?.mainData?.experience_type || ""}
                          label="Experience Type"
                          onChange={(e) => handleChange(e, idx)}
                          required
                        >
                          {[
                            "Internship",
                            "Freelance",
                            "Apprenticeship",
                            "Project",
                          ].map((type) => (
                            <MenuItem key={type} value={type}>
                              {type}
                            </MenuItem>
                          ))}
                        </Select>

                        {ExperienceErrors?.[idx]?.experience_type && (
                          <FormHelperText>
                            {ExperienceErrors?.[idx]?.experience_type}
                          </FormHelperText>
                        )}
                      </FormControl>

                      <TextField
                        fullWidth
                        label="Company Name"
                          disabled={mode ==="view"}
                        name="organization_name"
                        value={section?.mainData?.organization_name}
                        onChange={(e) => handleChange(e, idx)}
                        required
                        error={!!ExperienceErrors?.[idx]?.organization_name}
                        helperText={ExperienceErrors?.[idx]?.organization_name}
                        inputProps={{ maxLength: 100 }}
                      />

                      <FormControl
                        fullWidth
                        required
                       
                        error={!!ExperienceErrors?.[idx]?.general_industry_id}
                      >
                        <InputLabel id="industry-label">Industry</InputLabel>
                        <Select
                          labelId="industry-label"
                            disabled={mode ==="view"}
                          id="general_industry_id"
                          name="general_industry_id"
                          value={section?.mainData?.general_industry_id || ""}
                          onChange={(e) => handleChange(e, idx)}
                          label="Industry"
                        >
                          {(Industry || []).map((option) => (
                            <MenuItem
                              key={option.general_industry_id}
                              value={option.general_industry_id}
                            >
                              {option.industry_name}
                            </MenuItem>
                          ))}
                        </Select>
                        {ExperienceErrors?.[idx]?.general_industry_id && (
                          <FormHelperText>
                            {ExperienceErrors?.[idx]?.general_industry_id}
                          </FormHelperText>
                        )}
                      </FormControl>

                </Box>



                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                  }}
                >
                  <TextField
                        fullWidth
                        required
                        label="Location"
                          disabled={mode ==="view"}
                        name="location"
                        value={section?.mainData?.location}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.location}
                        helperText={ExperienceErrors?.[idx]?.location}
                        inputProps={{ maxLength: 50 }}
                      />


                      <TextField
                        fullWidth
                        required
                        label="Work Title"
                          disabled={mode ==="view"}
                        name="work_title"
                        value={section?.mainData?.work_title}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.work_title}
                        helperText={ExperienceErrors?.[idx]?.work_title}
                        inputProps={{ maxLength: 60 }}
                      />

                      <FormControl
                        fullWidth
                        required
                        error={!!ExperienceErrors?.[idx]?.work_mode}
                        // sx={{ marginTop: 2 }}
                      >


                        <InputLabel id="work_mode-label">Work Mode</InputLabel>

                        <Select
                          labelId="work_mode-label"
                            disabled={mode ==="view"}
                          id="work_mode"
                          name="work_mode"
                          value={section?.mainData?.work_mode || ""}
                          label="Work Mode"
                          onChange={(e) => handleChange(e, idx)}
                        >
                          {[
                            "Full-Time",
                            "Part-Time",
                            "Project-Based",
                            "Flexible",
                          ].map((option) => (
                            <MenuItem key={option} value={option}>
                              {option}
                            </MenuItem>
                          ))}
                        </Select>

                        {ExperienceErrors?.[idx]?.work_mode && (
                          <FormHelperText>
                            {ExperienceErrors?.[idx]?.work_mode}
                          </FormHelperText>
                        )}
                      </FormControl>

                  
                </Box>



                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                  }}
                >

                    <FormControl
                        fullWidth
                          disabled={mode ==="view"}
                        error={!!ExperienceErrors?.[idx]?.compensation_status}
                        // sx={{ marginTop: 2 }}
                      >
                        <InputLabel id="compensation_status-label">
                          Compensation Status
                        </InputLabel>

                        <Select
                          labelId="compensation_status-label"
                          id="compensation_status"
                          name="compensation_status"
                          value={section?.mainData?.compensation_status || ""}
                          label="Compensation Status"
                          onChange={(e) => handleChange(e, idx)}
                        >
                          {["Paid", "Unpaid"].map((option) => (
                            <MenuItem key={option} value={option}>
                              {option}
                            </MenuItem>
                          ))}
                        </Select>

                        {ExperienceErrors?.[idx]?.compensation_status && (
                          <FormHelperText>
                            {ExperienceErrors?.[idx]?.compensation_status}
                          </FormHelperText>
                        )}
                      </FormControl>






 <TextField
                          select
                          fullWidth
                          label="Currency Code"
                          
                          name="currency_code"
                          value={section?.mainData?.currency_code}
                          onChange={(e) => handleChange(e, idx)}
                          disabled={
                            section?.mainData?.compensation_status !== "Paid"  || mode === "view"
                          }
                          error={!!ExperienceErrors?.[idx]?.currency_code}
                          helperText={ExperienceErrors?.[idx]?.currency_code}
                        >
                          {(countrycode || [])?.map((option) => (
                            <MenuItem
                              key={option.currency_code}
                              value={option?.currency_code}
                            >
                              {option.currency_code}
                            </MenuItem>
                          ))}
                        </TextField>

                        <TextField
                          fullWidth
                          label="Compensation Amount"
                          name="compensation_amount"
                          type="number"
                          value={section?.mainData?.compensation_amount}
                          onChange={(e) => handleChange(e, idx)}
                          disabled={
                            section?.mainData?.compensation_status !== "Paid" || mode === "view"
                          }
                          error={!!ExperienceErrors?.[idx]?.compensation_amount}
                          helperText={
                            ExperienceErrors?.[idx]?.compensation_amount
                          }
                          inputProps={{ min: 0 }}
                        />

                </Box>
                       
                       
                       



                      

                    
                      {/* <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          width: "100%",
                          gap: "20px",
                        }}
                      >
                       
                      </div> */}


                      <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                    mt:3
                  }}
                >


                   <TextField
                        fullWidth
                        required
                        label="Start Date"
                          disabled={mode ==="view"}
                        type="date"
                        name="start_date"
                        value={section?.mainData?.start_date}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.start_date}
                        helperText={ExperienceErrors?.[idx]?.start_date}
                        InputLabelProps={{ shrink: true }}
                      />

                      <TextField
                        fullWidth
                        required
                        label="End Date"
                        type="date"
                          disabled={mode ==="view"}
                        name="end_date"
                        value={section?.mainData?.end_date}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.end_date}
                        helperText={ExperienceErrors?.[idx]?.end_date}
                        InputLabelProps={{ shrink: true }}
                      />


                </Box>
                       


                       <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                    mt:3
                  }}
                >

                    <TextField
                        fullWidth
                        label="Reporting Manager Name"
                          disabled={mode ==="view"}
                        name="reporting_manager_name"
                        value={section?.mainData?.reporting_manager_name}
                        onChange={(e) => handleChange(e, idx)}
                        error={
                          !!ExperienceErrors?.[idx]?.reporting_manager_name
                        }
                        helperText={
                          ExperienceErrors?.[idx]?.reporting_manager_name
                        }
                        inputProps={{ maxLength: 100 }}
                      />

                      <TextField
                        fullWidth
                        label="Reporting Manager No."
                          disabled={mode ==="view"}
                        name="reporting_manager_contact"
                        type="text"
                        value={section?.mainData?.reporting_manager_contact}
                        onChange={(e) => {
                          const input = e.target.value;
                          // ✔ Allow only digits, up to 15 characters
                          if (/^\d{0,20}$/.test(input)) {
                            handleChange(e, idx);
                          }
                        }}
                        error={
                          !!ExperienceErrors?.[idx]?.reporting_manager_contact
                        }
                        helperText={
                          ExperienceErrors?.[idx]?.reporting_manager_contact
                        }
                        inputProps={{
                          maxLength: 20,
                          inputMode: "numeric",
                          pattern: "[0-9]*",
                        }}
                      />




                </Box>
                       


                       <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                  }}
                >


                </Box>
                       

                     

                    
                      <FormControl
                        disabled={mode ==="view"}
                        component="fieldset"
                        error={!!ExperienceErrors?.[idx]?.is_verified}
                        // sx={{ mt: 2 }}
                      >
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={section?.mainData?.is_verified || false}
                              onChange={(e) => {
                                const { checked } = e.target;
                                handleCheckboxChange(e, idx);
                                if (!checked) {
                                  [
                                    "verified_by",
                                    "verification_notes",
                                    "verification_date",
                                  ].forEach((field) =>
                                    handleChange(
                                      {
                                        target: { name: field, value: "" },
                                      },
                                      idx
                                    )
                                  );
                                }
                              }}
                              name="is_verified"
                              color="primary"
                            />
                          }
                          label="Is Verified"
                        />
                        {ExperienceErrors?.[idx]?.is_verified && (
                          <FormHelperText>
                            {ExperienceErrors?.[idx]?.is_verified}
                          </FormHelperText>
                        )}
                      </FormControl>

                      <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center", // centers the row
                    gap: 2, // space between fields
                    width: "100%", // ensures proper centering
                  }}
                >

                   <TextField
                        fullWidth
                        label="Verified By(Person Name)"
                       
                        name="verified_by"
                        value={section?.mainData?.verified_by}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.verified_by}
                        helperText={ExperienceErrors?.[idx]?.verified_by}
                        inputProps={{ maxLength: 100 }}
                        disabled={!section?.mainData?.is_verified || mode === "view"}
                      />
                       <TextField
                        fullWidth
                        label="Verfication Date"
                        type="date"
                        name="verification_date"
                        value={section?.mainData?.verification_date}
                        onChange={(e) => handleChange(e, idx)}
                        error={!!ExperienceErrors?.[idx]?.verification_date}
                        helperText={ExperienceErrors?.[idx]?.verification_date}
                        InputLabelProps={{ shrink: true }}
                        disabled={!section?.mainData?.is_verified || mode === "view"}
                          
                      />

                  
                </Box>
                       

                     

                      <TextField
                        fullWidth
                        label="Verification Notes"
                        name="verification_notes"
                        value={section?.mainData?.verification_notes}
                        onChange={(e) => handleChange(e, idx)}
                        multiline
                        rows={4}
                        error={!!ExperienceErrors?.[idx]?.verification_notes}
                        helperText={ExperienceErrors?.[idx]?.verification_notes}
                        inputProps={{ maxLength: 256 }}
                        disabled={!section?.mainData?.is_verified || mode === "view"}
                      />

                     
                    </Grid>
                  </Paper>
                </Grid>
              )}
            </AccordionDetails>
          </Accordion>
        ))}
        <Button
          variant="contained"
            disabled={mode ==="view"}
          style={{ marginTop: 9 }}
          onClick={() => {
            setExpanded(`Experience ${Experience?.length + 1}`);
            addExperience();
          }}
        >
          Add More
        </Button>
      </Box>
    </Box>
  );
}

export default InternExperience;
