import { Button, Grid } from "@mui/material";
import useEmployeeDataStore from "../../Zustand/Store/useEmployeeDataStore";
import axios from "axios";
import { MAIN_URL } from "../../Configurations/Urls";
import useAuthStore from "../../Zustand/Store/useAuthStore";
import toast from "react-hot-toast";
import React, { useState, useEffect } from "react";
import { CircularProgress } from "@mui/material";

import { useNavigate, useParams } from "react-router-dom";

const SubmitButton = ({ mode }) => {
  let {
    Employee,
    setEmployeeErrors,
    setLanguageErrors,
    setEducationError,
    setFamilyError,
    setAddressError,
    setContactError,
    setExperienceError,
    setMedicalError,
    setPaymentMethodError,
    Education,
    EducationErrors,
    LanguageErrors,
    FamilyErrors,
    AddressErrors,
    ContactErrors,
    ExperienceErrors,
    MedicalErrors,
    PaymentMethodErrors,
    Language,
    setEmployee,
    Family,
    Address,
    Contact,
    Experience,
    Medical,
    PaymentMethod,
    resetData,
    setEducation,
    setLanguage,
    setFamily,
    setAddress,
    setContact,
    setExperience,
    setMedical,
    setPaymentMethod,
    DocumentErrors,
    setDocument,
    Document,
    setDocumentError,
  } = useEmployeeDataStore();

  const { userData } = useAuthStore();
  const org = userData?.organization;

  let navigate = useNavigate();

  const { id } = useParams();
  const [loading, setLoading] = useState(false);

  console.log("is is ", id);

  console.log("Employee:", Employee);
  console.log("Education:", Education);
  console.log("Language:", Language);
  console.log("Family:", Family);
  console.log("Address:", Address);
  console.log("Contact:", Contact);
  console.log("Experience:", Experience);
  console.log("Medical:", Medical);
  console.log("PaymentMethod:", PaymentMethod);
  console.log("document is ", Document);

  console.log("education errtor", EducationErrors);

  console.log("language  errtor ", LanguageErrors);

  console.log("family  errtor", FamilyErrors);

  console.log("address  errtor ", AddressErrors);
  console.log("document  errtor ", DocumentErrors);

  console.log("contact  errtor", ContactErrors);
  console.log("experience  errtor", ExperienceErrors);

  console.log("medical  errtor", MedicalErrors);
  console.log("payment   errtor", PaymentMethodErrors);

  const validateForm1 = () => {
    const errors = {};

    if (!Employee.employee_code)
      errors.employee_code = "Employee Code is required.";

    if (!Employee.first_name) errors.first_name = "First Name is required.";

    if (!Employee?.date_of_birth)
      errors.date_of_birth = "Date of Birth is required.";

    if (!Employee?.gender) errors.gender = "Gender is required.";

    if (!Employee?.marital_status)
      errors.marital_status = "Marital Status is required.";

    if (!Employee.organization_department_id)
      errors.organization_department_id = "Location/Department is required.";

    if (!Employee.organization_designation_id)
      errors.organization_designation_id = "Designation is required.";

    if (!Employee.organization_employment_type_id)
      errors.organization_employment_type_id = "Employment Type is required.";

    if (!Employee.organization_employment_category_id)
      errors.organization_employment_category_id =
        "Employment Category is required.";

    if (!Employee.organization_work_shift_id)
      errors.organization_work_shift_id = "Workshift is required.";

    if (!Employee.organization_employment_stage_id)
      errors.organization_employment_stage_id = "Employment Stage is required.";

    if (!Employee.date_of_joining)
      errors.date_of_joining = "Date of Joining is required.";

    // Optional: Validate specific formats
    // const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    // if (Employee.date_of_birth && !dateRegex.test(Employee.date_of_birth)) {
    //   errors.date_of_birth = "Date of Birth must be in YYYY-MM-DD format.";
    // }
    // if (Employee.date_of_joining && !dateRegex.test(Employee.date_of_joining)) {
    //   errors.date_of_joining = "Date of Joining must be in YYYY-MM-DD format.";
    // }

    if (Object.keys(errors)?.length > 0) {
      const firstKey = Object.keys(errors)[0];
      const firstError = errors[firstKey];
      toast.error(firstError); // ✔ Show most recent (first) error
      setEmployeeErrors(errors);
      return false;
    }
    setEmployeeErrors({});
    return true;
  };

  const validateForm2 = () => {
    const allErrors = {};
    let firstErrorMessage = null;

    const isFilled = (item) =>
      item.organization_education_level_id ||
      item.organization_education_degree_id ||
      item.organization_education_stream_id ||
      item.institute_name ||
      item.board_university_name ||
      (item.marks_percentage !== "" &&
        item.marks_percentage !== null &&
        item.marks_percentage !== undefined) ||
      item.year_of_passing ||
      item.is_pursuing ||
      item.employee_id ||
      item.organization_id;

    const filteredEducation = Education.filter(isFilled);

    // Now validate only filled entries
    filteredEducation.forEach((edu, index) => {
      const errors = {};

      if (!edu.organization_education_level_id)
        errors.organization_education_level_id = "Education Level is required.";

      if (
        edu.organization_education_degree_id &&
        edu.organization_education_stream_id
      ) {
        if (!edu.board_university_name?.trim())
          errors.board_university_name = "University Board is required.";
      }

      if (!edu.institute_name)
        errors.institute_name = "Institute name is required.";

      if (!edu.board_university_name)
        errors.board_university_name = "Board name is required.";

      // if (!edu.marks_percentage && edu.marks_percentage !== 0) {
      //   errors.marks_percentage = "Marks percentage is required.";
      // } else if (isNaN(edu.marks_percentage)) {
      //   errors.marks_percentage = "Marks percentage must be a number.";
      // } else if (edu.marks_percentage < 0 || edu.marks_percentage > 100) {
      //   errors.marks_percentage = "Marks percentage must be between 0 and 100.";
      // }

      // if (!edu.year_of_passing)
      //   errors.year_of_passing = "Year of passing is required.";

      if (Object.keys(errors)?.length > 0) {
        allErrors[index] = errors;
        if (!firstErrorMessage) {
          const firstKey = Object.keys(errors)[0];
          firstErrorMessage = errors[firstKey];
        }
      }
    });

    if (firstErrorMessage) {
      toast.error(firstErrorMessage);
      setEducationError(allErrors);
      return false;
    }

    setEducationError({});
    setEducation(filteredEducation);

    return true;
  };

  const validateForm3 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.employee_id ||
      item.language_id ||
      item.can_read ||
      item.can_write ||
      item.can_speak ||
      item.is_native ||
      item.description ||
      item.organization_id;

    const filtered = Language.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};
      if (!item.language_id) errors.language_id = "Language is required.";

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setLanguageErrors(allErrors);
      setLanguage(filtered);
      return false;
    }

    setLanguageErrors({});
    setLanguage(filtered);
    return true;
  };

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  };

  const validateForm4 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.organization_employee_address_type_id ||
      item.address_line1 ||
      item.address_line2 ||
      item.address_line3 ||
      item.general_city_id ||
      item.postal_code ||
      item.organization_residential_ownership_type_id ||
      item.employee_id ||
      item.organization_id;

    const filtered = Address.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};
      if (!item.organization_employee_address_type_id)
        errors.organization_employee_address_type_id =
          "Employee Address Type is required.";

      // if (!item?.organization_residential_ownership_type_id)
      //   errors.organization_residential_ownership_type_id =
      //     "Residential Type is required.";

      if (!item.address_line1)
        errors.address_line1 = "Employee Address is required.";

      if (!item.general_city_id) errors.general_city_id = "City is required.";

      if (!item.postal_code) errors.postal_code = "Postal is required.";

      if (!item.organization_residential_ownership_type_id)
        errors.organization_residential_ownership_type_id =
          "Residential Type is required.";

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setAddressError(allErrors);
      setAddress(filtered);
      return false;
    }

    setAddressError({});
    setAddress(filtered);
    return true;
  };

  const validateForm5 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.employee_id ||
      item.personal_phone_number ||
      item.alternate_personal_phone_number ||
      item.personal_email ||
      item.alternate_personal_email ||
      item.preferred_contact_method ||
      item.emergency_person_phone_number_1 ||
      item.emergency_person_name_1 ||
      item.emergency_person_relation_1 ||
      item.emergency_person_phone_number_2 ||
      item.emergency_person_name_2 ||
      item.emergency_person_relation_2 ||
      item.work_phone_number ||
      item.work_email ||
      item.organization_id;

    const isValidPhone = (phone) => /^(\+?\d{1,3}[- ]?)?\d{10}$/.test(phone);
    const isValidEmail = (email) => {
      // Local part + @ + domain + TLD (letters only, min 2)
      const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
      return emailRegex.test(email.trim());
    };

    const validContactMethods = ["phone", "email", "message"];

    const filtered = Contact.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.personal_phone_number) {
        errors.personal_phone_number = "Personal phone number is required.";
      } else if (!isValidPhone(item.personal_phone_number)) {
        errors.personal_phone_number = "Enter a valid 10-digit phone number.";
      }

      if (!item.personal_email) {
        errors.personal_email = "Personal email is required.";
      } else if (!isValidEmail(item.personal_email)) {
        errors.personal_email = "Enter a valid personal email address.";
      }

      if (!item.preferred_contact_method) {
        errors.preferred_contact_method =
          "Preferred contact method is required.";
      } else if (
        !validContactMethods.includes(
          item.preferred_contact_method.toLowerCase()
        )
      ) {
        errors.preferred_contact_method =
          "Preferred contact method must be 'phone', 'email' or 'message'.";
      }

      if (!item.emergency_person_name_1)
        errors.emergency_person_name_1 =
          "Emergency contact 1 name is required.";

      if (!item.work_email) errors.work_email = "Work email is required.";

      if (!item.emergency_person_phone_number_1) {
        errors.emergency_person_phone_number_1 =
          "Emergency contact 1 phone is required.";
      } else if (!isValidPhone(item.emergency_person_phone_number_1)) {
        errors.emergency_person_phone_number_1 =
          "Enter a valid emergency contact 1 phone number.";
      }

      if (!item.emergency_person_relation_1)
        errors.emergency_person_relation_1 =
          "Relation with emergency contact 1 is required.";

      if (item.work_email && !isValidEmail(item.work_email)) {
        errors.work_email = "Enter a valid work email address.";
      }

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setContactError(allErrors);
      setContact(filtered);
      return false;
    }

    setContactError({});
    setContact(filtered);
    return true;
  };

  const validateForm6 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.organization_name ||
      item.work_title ||
      item.employee_id ||
      item.work_mode ||
      item.experience_type ||
      item.compensation_status ||
      item.general_industry_id ||
      item.start_date ||
      item.end_date ||
      item.compensation_payout_model ||
      item.currency_code ||
      item.compensation_amount ||
      item.location ||
      item.reporting_manager_name ||
      item.reporting_manager_contact ||
      item.description ||
      item.is_verified ||
      item.verified_by ||
      item.verification_date ||
      item.verification_notes ||
      item.organization_id;

    const filtered = Experience.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.experience_type)
        errors.experience_type = "Experience Type is required.";

      if (!item.organization_name)
        errors.organization_name = "Company Name is required.";

      if (!item.start_date) errors.start_date = "start date is required.";

      if (!item.end_date) errors.end_date = "start date is required.";

      if (!item.general_industry_id)
        errors.general_industry_id = "Industry is required.";

      if (!item.location) errors.location = "Loaction is required.";

      if (!item.work_title) errors.work_title = "work title is required.";

      if (!item.work_mode) errors.work_mode = "work mode is required.";

      if (!item.compensation_status)
        errors.compensation_status = "work status is required.";

      if (item.is_verified) {
        if (!item.verified_by)
          errors.verified_by = "Verified Person Name is required";
        if (!item.verification_date)
          errors.verification_date = "Verification Date is required";
      }

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setExperienceError(allErrors);
      setExperience(filtered);
      return false;
    }

    setExperienceError({});
    setExperience(filtered);
    return true;
  };

  const validateForm7 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.employee_id ||
      item.blood_group ||
      item.allergies ||
      item.diseases ||
      item.disability_status ||
      item.disability_description ||
      item.is_fit_for_duty ||
      item.last_health_check_date ||
      item.medical_notes ||
      item.organization_id;

    const filtered = Medical.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.blood_group) errors.blood_group = "Blood Group is required.";
      if (!item.disability_status)
        errors.disability_status = "Disability Status is required.";
      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setMedicalError(allErrors);
      setMedical(filtered);
      return false;
    }

    setMedicalError({});
    setMedical(filtered);
    return true;
  };

  const validateForm8 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.organization_id ||
      item.employee_id ||
      item.account_holder_name ||
      item.bank_name ||
      item.ifsc_code ||
      item.account_number ||
      item.account_type ||
      item.is_primary ||
      item.qr_code_url ||
      item.remarks ||
      item.upi_id;

    const uriPattern =
      /^(upi:\/\/pay\?.+|https?:\/\/[\w\-._~:/?#@!$&'()*+,;=%]+|bitcoin:[\w]+|BCD[\w\d]+)$/i;

    const filtered = PaymentMethod.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.bank_name) errors.bank_name = "Bank Name is required.";
      if (!item.account_holder_name)
        errors.account_holder_name = "A/C holder Name is required.";
      if (!item.account_type) errors.account_type = "A/C Type is required.";

      if (!item.account_number) {
        errors.account_number = "A/C No. is required.";
      } else if (!/^\d+$/.test(item.account_number)) {
        errors.account_number = "A/C No. must be numeric.";
      } else if (item.account_number?.length < 9) {
        errors.account_number = "A/C No. must be at least 9 digits.";
      } else if (item.account_number?.length > 18) {
        errors.account_number = "A/C No. must not exceed 18 digits.";
      }

      if (item.qr_code_url && !uriPattern.test(item.qr_code_url)) {
        errors.qr_code_url = "Enter a valid payment URI (UPI, PayPal, etc.)";
      }

      if (!item.ifsc_code) {
        errors.ifsc_code = "IFSC Code is required";
      }
      // else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(item.ifsc_code)) {
      //   errors.ifsc_code = "Invalid IFSC Code format";
      // }

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setPaymentMethodError(allErrors);
      setPaymentMethod(filtered);
      return false;
    }

    setPaymentMethodError({});
    setPaymentMethod(filtered);
    return true;
  };

  const validateForm9 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.employee_id ||
      item.name ||
      item.relationship ||
      item.phone ||
      item.marital_status ||
      item.current_status ||
      item.education_details ||
      item.occupation_details ||
      item.email ||
      item.description ||
      item.date_of_birth ||
      item.is_dependent ||
      item.organization_id;

    const filtered = Family.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.name) errors.name = "Name of Relative is required.";
      if (!item.relationship) errors.relationship = "Relationship is required.";
      // if (!item.phone) errors.phone = "Phone No. is required.";

      if (!item.marital_status)
        errors.marital_status = "Marital Status is required.";

      if (!item.current_status)
        errors.current_status = "Current Status is required.";
      if (item.email && !isValidEmail(item.email)) {
        errors.email = "Enter a valid  email address.";
      }

      if (Object.keys(errors)?.length > 0) {
        allErrors[idx] = errors;
        if (!firstError) firstError = errors[Object.keys(errors)[0]];
      }
    });

    if (firstError) {
      toast.error(firstError);
      setFamilyError(allErrors);
      setFamily(filtered);
      return false;
    }

    setFamilyError({});
    setFamily(filtered);
    return true;
  };

  function printFormData(formData) {
    console.log("----- FormData Contents -----");
    for (let pair of formData.entries()) {
      console.log("helloe ", pair[0], ":", pair[1]);
    }
    console.log("-----------------------------");
  }

  const validateForm10 = () => {
    const allErrors = {};
    let firstError = null;

    const isFilled = (item) =>
      item.employee_id ||
      item.employee_document_type_id ||
      item.organization_id ||
      item.document_name ||
      item.document_url ||
      item.document_size_kb ||
      item.organization_employee_profile_section_id;

    const filtered = Document.filter(isFilled);

    filtered.forEach((item, idx) => {
      const errors = {};

      if (!item.employee_document_type_id) {
        errors.employee_document_type_id = "Document Type is required.";
      }

      if (!item.document_name) {
        errors.document_name = "Document Name  is required.";
      }
    });

    if (firstError) {
      toast.error(firstError);
      setDocumentError(allErrors);
      setDocument(filtered);
      return false;
    }

    setDocumentError({});
    setDocument(filtered);
    return true;
  };

  // const formatDate = (dateStr) => {
  //   if (!dateStr) return "";
  //   const date = new Date(dateStr);
  //   if (isNaN(date)) return "";
  //   const day = String(date.getDate()).padStart(2, "0");
  //   const month = String(date.getMonth() + 1).padStart(2, "0");
  //   const year = date.getFullYear();
  //   return `${year}-${month}-${day}`; // e.g., "2002-11-02"
  // };

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    // Extract the YYYY-MM-DD portion from ISO string
    return dateStr.split("T")[0];
  };

  useEffect(() => {
    const fetchEmployeeData = async () => {
      if (mode === "edit" || mode === "view") {
        try {
          const response = await axios.get(
            `${MAIN_URL}/api/organizations/${org?.organization_id}/employee-store/update/${id}`,
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
            }
          );
          console.log("Employee fetched:", response.data);
          // response.data.employee.date_of_birth = formatDate(
          //   response.data.employee.date_of_birth
          // );
          // response.data.employee.date_of_joining = formatDate(
          //   response.data.employee.date_of_joining
          // );

          response.data.employee.date_of_birth = formatDate(
            response.data.employee.date_of_birth
          );
          response.data.employee.date_of_joining = formatDate(
            response.data.employee.date_of_joining
          );

          response.data.employee.organization_department_id =
            response?.data?.employee?.department_location[0]?.organization_department_id;
          setEmployee(response.data.employee);

          // response?.data?.education?.organization_education_degree_id = response?.data?.education?.degree?.[0]?.organization_education_degree_id
          setEducation(
            response.data.education?.length > 0
              ? response.data.education
              : [
                  {
                    organization_education_level_id: "",
                    organization_education_degree_id: "",
                    organization_education_stream_id: "",
                    institute_name: "",
                    board_university_name: "",
                    marks_percentage: "",
                    year_of_passing: "",
                    is_pursuing: "",
                    employee_id: "",
                    organization_id: "",
                  },
                ]
          );
          setLanguage(
            response.data.language?.length > 0
              ? response.data.language
              : [
                  {
                    employee_language_id: "",
                    employee_id: "",
                    language_id: "",
                    can_read: false,
                    can_write: false,
                    can_speak: false,
                    is_native: false,
                    description: "",
                    organization_id: "",
                  },
                ]
          );

          response.data.family = response.data?.family.map((item) => ({
            ...item,
            date_of_birth:
              item.date_of_birth == null
                ? null
                : formatDate(item.date_of_birth),
          }));

          setFamily(
            response.data.family?.length > 0
              ? response.data.family
              : [
                  {
                    employee_family_member_id: "",
                    employee_id: "",
                    name: "",
                    relationship: "",
                    phone: "",
                    date_of_birth: "",
                    is_dependent: "",
                    marital_status: "",
                    current_status: "",
                    education_details: "",
                    occupation_details: "",
                    email: "",
                    description: "",
                    organization_id: "",
                  },
                ]
          );

          setAddress(
            response.data.address?.length > 0
              ? response.data.address
              : [
                  {
                    organization_employee_address_type_id: "",
                    address_line1: "",
                    address_line2: "",
                    address_line3: "",
                    general_city_id: "",
                    postal_code: "",
                    organization_residential_ownership_type_id: "",
                    employee_id: "",
                    organization_id: "",
                  },
                ]
          );
          setContact(
            response.data.contact?.length > 0
              ? response.data.contact
              : [
                  {
                    employee_id: "",
                    personal_phone_number: "",
                    alternate_personal_phone_number: "",
                    personal_email: "",
                    alternate_personal_email: "",
                    preferred_contact_method: "",
                    emergency_person_phone_number_1: "",
                    emergency_person_name_1: "",
                    emergency_person_relation_1: "",
                    emergency_person_phone_number_2: "",
                    emergency_person_name_2: "",
                    emergency_person_relation_2: "",
                    work_phone_number: "",
                    work_email: "",
                    organization_id: "",
                  },
                ]
          );
          setExperience(
            response.data.experience?.length > 0
              ? response.data.experience
              : [
                  {
                    employee_experience_id: "",
                    employee_id: "",
                    organization_name: "",
                    work_title: "",
                    experience_type: "",
                    description: "",
                    general_industry_id: "",
                    work_mode: "",
                    start_date: "",
                    end_date: "",
                    currency_code: "",
                    location: "",
                    compensation_status: "",
                    compensation_payout_model: "",
                    compensation_amount: "",
                    reporting_manager_name: "",
                    reporting_manager_contact: "",
                    is_verified: false,
                    verified_by: "",
                    verification_date: "",
                    verification_notes: "",
                    organization_id: "",
                  },
                ]
          );
          setMedical(
            response.data.medical?.length > 0
              ? response.data.medical
              : [
                  {
                    employee_medical_id: "",
                    employee_id: "",
                    blood_group: "",
                    allergies: "",
                    diseases: "",
                    disability_status: "",
                    disability_description: "",
                    is_fit_for_duty: false,
                    last_health_check_date: "",
                    medical_notes: "",
                    organization_id: "",
                  },
                ]
          );
          setPaymentMethod(
            response.data.payment_method?.length > 0
              ? response.data.payment_method
              : [
                  {
                    employee_bank_account_id: "",
                    organization_id: "",
                    employee_id: "",
                    account_holder_name: "",
                    bank_name: "",
                    ifsc_code: "",
                    account_number: "",
                    account_type: false,
                    is_primary: false,
                    qr_code_url: "",
                    remarks: "",
                    upi_id: "",
                  },
                ]
          );

          setDocument(
            response.data.document?.length > 0
              ? response.data.document.map((item) => {
                  return {
                    ...item,

                    organization_employee_profile_section_id:
                      item.section_link.map((i) => {
                        return i.profile_section
                          .organization_employee_profile_section_id;
                      }),
                  };
                })
              : [
                  {
                    organization_id: "",
                    employee_id: "",
                    document_name: "",
                    document_url: "",
                    employee_document_type_id: "",
                    document_size_kb: "",
                    organization_employee_profile_section_id: "",
                  },
                ]
          );
        } catch (error) {
          console.error("Error fetching employee data:", error);
        }
      }
    };

    fetchEmployeeData();
  }, [mode, id]);

  const handleSubmit = async () => {
    try {
      if (!validateForm1()) return;

      // check has education
      // let sectionData = {};

      let FiiledEducation = Education?.filter(
        (item) =>
          item.organization_education_level_id != "" ||
          item.organization_education_degree_id != "" ||
          item.organization_education_stream_id != "" ||
          item.institute_name != "" ||
          item.board_university_name != "" ||
          item.marks_percentage != "" ||
          item.year_of_passing != "" ||
          item.is_pursuing != "" ||
          item.employee_id != "" ||
          item.organization_id != ""
      );

      let FiiledLanguage = Language?.filter(
        (item) =>
          item.employee_id != "" ||
          item.language_id != "" ||
          item.can_read != false ||
          item.can_write != false ||
          item.can_speak != false ||
          item.is_native != false ||
          item.description != "" ||
          item.organization_id != ""
      );

      let FiiledFamily = Family?.filter(
        (item) =>
          item.employee_id != "" ||
          item.name != "" ||
          item.relationship != "" ||
          item.phone != "" ||
          item.date_of_birth != "" ||
          item.marital_status != "" ||
          item.current_status != "" ||
          item.education_details != "" ||
          item.occupation_details != "" ||
          item.email != "" ||
          item.description != "" ||
          item.is_dependent != "" ||
          item.organization_id != ""
      );

      let FiiledAddress = Address?.filter(
        (item) =>
          item.organization_employee_address_type_id != "" ||
          item.address_line1 != "" ||
          item.address_line2 != "" ||
          item.address_line3 != "" ||
          item.general_city_id != "" ||
          item.postal_code != "" ||
          item.organization_residential_ownership_type_id != "" ||
          item.employee_id != "" ||
          item.organization_id != ""
      );

      let FiiledContact = Contact?.filter(
        (item) =>
          item.employee_id != "" ||
          item.personal_phone_number != "" ||
          item.alternate_personal_phone_number != "" ||
          item.personal_email != "" ||
          item.alternate_personal_email != "" ||
          item.preferred_contact_method != "" ||
          item.emergency_person_phone_number_1 != "" ||
          item.emergency_person_name_1 != "" ||
          item.emergency_person_relation_1 != "" ||
          item.emergency_person_phone_number_2 != "" ||
          item.emergency_person_name_2 != "" ||
          item.emergency_person_relation_2 != "" ||
          item.work_phone_number != "" ||
          item.work_email != "" ||
          item.organization_id != ""
      );

      let FiiledExperience = Experience?.filter(
        (item) =>
          item.organization_name ||
          item.work_title != "" ||
          item.employee_id != "" ||
          item.work_mode != "" ||
          item.experience_type != "" ||
          item.compensation_status != "" ||
          item.general_industry_id != "" ||
          item.start_date != "" ||
          item.end_date != "" ||
          item.compensation_payout_model != "" ||
          item.currency_code != "" ||
          item.compensation_amount != "" ||
          item.location != "" ||
          item.reporting_manager_name != "" ||
          item.reporting_manager_contact != "" ||
          item.description != "" ||
          item.is_verified != "" ||
          item.verified_by != "" ||
          item.verification_date != "" ||
          item.verification_notes != "" ||
          item.organization_id != ""
      );

      let FiiledMedical = Medical?.filter(
        (item) =>
          item.employee_id != "" ||
          item.blood_group != "" ||
          item.allergies != "" ||
          item.diseases != "" ||
          item.disability_status != "" ||
          item.disability_description != "" ||
          item.is_fit_for_duty != false ||
          item.last_health_check_date != "" ||
          item.medical_notes != "" ||
          item.organization_id != ""
      );

      let FiiledPaymentMethod = PaymentMethod?.filter(
        (item) =>
          item.organization_id != "" ||
          item.employee_id != "" ||
          item.account_holder_name != "" ||
          item.bank_name != "" ||
          item.ifsc_code != "" ||
          item.account_number != "" ||
          item.account_type != false ||
          item.is_primary != false ||
          item.qr_code_url != "" ||
          item.remarks != "" ||
          item.upi_id != ""
      );

      let FiiledDocument = Document?.filter(
        (item) =>
          item.organization_id != "" ||
          item.employee_id != "" ||
          item.employee_document_type_id != "" ||
          item.document_name != "" ||
          item.document_url != "" ||
          item.document_size_kb != "" ||
          item.organization_employee_profile_section_id != ""
      );

      if (FiiledEducation?.length > 0) {
        if (!validateForm2()) return;
      }

      if (FiiledLanguage?.length > 0) {
        if (!validateForm3()) return;
      }
      if (FiiledFamily?.length > 0) {
        if (!validateForm9()) return;
      }
      if (FiiledAddress?.length > 0) {
        if (!validateForm4()) return;
      }
      if (FiiledContact?.length > 0) {
        if (!validateForm5()) return;
      }
      if (FiiledExperience?.length > 0) {
        if (!validateForm6()) return;
      }
      if (FiiledMedical?.length > 0) {
        if (!validateForm7()) return;
      }
      if (FiiledPaymentMethod?.length > 0) {
        if (!validateForm8()) return;
      }

      if (FiiledDocument?.length > 0) {
        if (!validateForm10()) return;
      }

      const formData = new FormData();

      // Employee fields
      Object.entries(Employee).forEach(([key, value]) => {
        if (key === "profile_image_url" && value instanceof File) {
          formData.append("profile_image_url", value);
        } else {
          formData.append(key, value ?? "");
        }
      });

      // Ensure all nested sections are valid arrays before sending

      const response = await axios.post(
        `${MAIN_URL}/api/organizations/${org.organization_id}/employee-store/store1`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      response.data.employee.date_of_birth = formatDate(
        response.data.employee.date_of_birth
      );
      response.data.employee.date_of_joining = formatDate(
        response.data.employee.date_of_joining
      );
      response.data.employee.organization_department_id =
        response?.data?.employee?.department_location?.[0]?.organization_department_id;

      setEmployee(response?.data?.employee);

      if (response.data.education?.length > 0) {
        setEducation(response.data.education);
      }
      if (response.data.language?.length > 0) {
        setLanguage(response.data.language);
      }
      if (response.data.family?.length > 0) {
        setFamily(response.data.family);
      }
      if (response.data.address?.length > 0) {
        setAddress(response.data.address);
      }
      if (response.data.contact?.length > 0) {
        setContact(response.data.contact);
      }
      if (response.data.experience?.length > 0) {
        setExperience(response.data.experience);
      }
      if (response.data.medical?.length > 0) {
        setMedical(response.data.medical);
      }
      if (response.data.payment_method?.length > 0) {
        setPaymentMethod(response.data.payment_method);
      }
      if (response.data.document?.length > 0) {
        setDocument(response.data.document);
      }

      let emp_id = response.data.employee.employee_id;

      console.log("FiiledEducation is:", FiiledEducation);

      let sectionData = {}; // This will hold all sections

      // Prepare documents as FormData if there is any
      if (FiiledDocument?.length > 0) {
        sectionData.document = Document?.map((item) => ({
          ...item,
          employee_id: emp_id,
          document_url:
            item.document_url instanceof File
              ? item.document_url
              : item.document_url || "",
        }));
      }

      // Prepare other sections
      if (FiiledEducation?.length > 0) {
        sectionData.education = Education?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledLanguage?.length > 0) {
        sectionData.language = Language?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledFamily?.length > 0) {
        sectionData.family = Family?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledAddress?.length > 0) {
        sectionData.address = Address?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledContact?.length > 0) {
        sectionData.contact = Contact?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledExperience?.length > 0) {
        sectionData.experience = Experience?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledMedical?.length > 0) {
        sectionData.medical = Medical?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      if (FiiledPaymentMethod?.length > 0) {
        sectionData.payment_method = PaymentMethod?.map((item) => ({
          ...item,
          employee_id: emp_id,
        }));
      }

      // Check if any section exists before sending
      if (
        FiiledEducation?.length > 0 ||
        FiiledLanguage?.length > 0 ||
        FiiledFamily?.length > 0 ||
        FiiledAddress?.length > 0 ||
        FiiledContact?.length > 0 ||
        FiiledExperience?.length > 0 ||
        FiiledMedical?.length > 0 ||
        FiiledPaymentMethod?.length > 0 ||
        FiiledDocument?.length > 0
      ) {
        // If there are documents as File objects, use FormData
        let finalData;
        let headers = {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        };

        const hasFile = FiiledDocument?.some(
          (doc) => doc.document_url instanceof File
        );

        if (hasFile) {
          finalData = new FormData();

          Object.keys(sectionData).forEach((key) => {
            sectionData[key].forEach((item, index) => {
              Object.keys(item).forEach((field) => {
                const value = item[field];

                if (value instanceof File) {
                  finalData.append(`${key}[${index}][${field}]`, value);
                } else if (Array.isArray(value)) {
                  // Append each array element individually
                  value.forEach((v, arrIndex) => {
                    finalData.append(
                      `${key}[${index}][${field}][${arrIndex}]`,
                      v
                    );
                  });
                } else if (typeof value === "boolean") {
                  finalData.append(`${key}[${index}][${field}]`, value ? 1 : 0);
                } else if (typeof value === "number") {
                  finalData.append(`${key}[${index}][${field}]`, value);
                } else {
                  finalData.append(`${key}[${index}][${field}]`, value ?? "");
                }
              });
            });
          });
        } else {
          finalData = sectionData;
          headers["Content-Type"] = "application/json";
        }

        try {
          console.log("----- FormData Contents -----");
          for (let pair of finalData.entries()) {
            console.log("helloe ", pair[0], ":", pair[1]);
          }
          console.log("-----------------------------");
        } catch (error) {
          console.log("erropr is ", error);
        }
        const response2 = await axios.post(
          `${MAIN_URL}/api/organizations/${org?.organization_id}/employee-store/store2`,
          finalData,
          { headers }
        );
      }

      console.log("Submitted successfully:", response.data);
      toast.success(
        `Employee data ${mode == "edit" ? "Edited" : "Added"} successfully!`
      );
      resetData();
      navigate(-1);
    } catch (error) {
      if (error.response?.data?.errors) {
        let hasEducationError =
          error.response.data.errors.education != undefined;
        let hasLanguageError = error.response.data.errors.language != undefined;
        let hasFamilyError = error.response.data.errors.family != undefined;
        let hasAddressError = error.response.data.errors.address != undefined;
        let hasContactError = error.response.data.errors.contact != undefined;

        let hasExperienceError =
          error.response.data.errors.experience != undefined;
        let hasMedicalError = error.response.data.errors.medical != undefined;
        let hasPaymentMethodError =
          error.response.data.errors.payment_method != undefined;

        let hasDocumentError = error.response.data.errors.document != undefined;

        if (error.response.data.section === "employee") {
          const errors = error.response.data.errors;
          const firstSection = Object.keys(errors)[0];
          setEmployeeErrors(error.response.data.errors);
          toast.error(
            `Validation error in ${firstSection == "employee_code" && "Employee Code"}: ${firstSection == "employee_code" && "The Employee code is already taken"}`
          );
        } else if (hasEducationError) {
          const errors = error.response.data.errors;
          const educationErrorsArray = errors?.education ?? [];
          if (educationErrorsArray?.length > 0) {
            const educationErrors = educationErrorsArray[0];
            setEducationError(educationErrors);
            const firstField = Object.keys(educationErrors)[0];
            const firstMessage = educationErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasLanguageError) {
          const errors = error.response.data.errors;
          const languageErrorsArray = errors?.language ?? [];
          if (languageErrorsArray?.length > 0) {
            const languageErrors = languageErrorsArray[0];
            setLanguageErrors(languageErrors);
            const firstField = Object.keys(languageErrors)[0];
            const firstMessage = languageErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasFamilyError) {
          const errors = error.response.data.errors;
          const familyErrorsArray = errors?.family ?? [];
          if (familyErrorsArray?.length > 0) {
            const familyErrors = familyErrorsArray[0];
            setFamilyError(familyErrors);
            const firstField = Object.keys(familyErrors)[0];
            const firstMessage = familyErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasAddressError) {
          const errors = error.response.data.errors;
          const addressErrorsArray = errors?.address ?? [];
          if (addressErrorsArray?.length > 0) {
            const addressErrors = addressErrorsArray[0];
            setAddressError(addressErrors);
            const firstField = Object.keys(addressErrors)[0];
            const firstMessage = addressErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasContactError) {
          const errors = error.response.data.errors;
          const contactErrorsArray = errors?.contact ?? [];
          if (contactErrorsArray?.length > 0) {
            const contactErrors = contactErrorsArray[0];
            setContactError(contactErrors);
            const firstField = Object.keys(contactErrors)[0];
            const firstMessage = contactErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasExperienceError) {
          const errors = error.response.data.errors;
          const experienceErrorsArray = errors?.experience ?? [];
          if (experienceErrorsArray?.length > 0) {
            const experienceErrors = experienceErrorsArray[0];
            setExperienceError(experienceErrors);
            const firstField = Object.keys(experienceErrors)[0];
            const firstMessage = experienceErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasMedicalError) {
          const errors = error.response.data.errors;
          const medicalErrorsArray = errors?.medical ?? [];
          if (medicalErrorsArray?.length > 0) {
            const medicalErrors = medicalErrorsArray[0];
            setEducationError(medicalErrors);
            const firstField = Object.keys(medicalErrors)[0];
            const firstMessage = medicalErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasPaymentMethodError) {
          const errors = error.response.data.errors;
          const PaymentmethodErrorsArray = errors?.payment_method ?? [];
          if (PaymentmethodErrorsArray?.length > 0) {
            const PaymentmethodErrors = PaymentmethodErrorsArray[0];
            setEducationError(PaymentmethodErrors);
            const firstField = Object.keys(PaymentmethodErrors)[0];
            const firstMessage = PaymentmethodErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        } else if (hasDocumentError) {
          const errors = error.response.data.errors;
          const DocumentErrorsArray = errors?.document ?? [];
          if (DocumentErrorsArray?.length > 0) {
            const DocumentErrors = DocumentErrorsArray[0];
            setDocumentError(DocumentErrors);
            const firstField = Object.keys(DocumentErrors)[0];
            const firstMessage = DocumentErrors[firstField][0];
            toast.error(`Validation error in ${firstField}: ${firstMessage}`);
          }
        }
        console.error("Validation Errors:", error.response);
      } else {
        console.error("Submit Error:", error);
        alert("Submission failed.");
      }
    }
  };

  const handleSubmitClick = async () => {
    setLoading(true);
    try {
      await handleSubmit();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Grid container spacing={2} mt={2}>
      <Grid item>
        <Button
          variant="contained"
          color="primary"
          size="medium"
          sx={{
            borderRadius: 2,
            minWidth: 120,
            textTransform: "capitalize",
            fontWeight: 500,
          }}
          onClick={handleSubmitClick}
          disabled={loading || mode === "view"}
        >
          {loading ? <CircularProgress size={22} color="inherit" /> : "Submit"}
        </Button>
      </Grid>

      {mode === "edit" ||
        (mode === "view" && (
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              size="medium"
              onClick={() => navigate(-1)}
              sx={{
                borderRadius: 2,
                minWidth: 120,
                textTransform: "capitalize",
                fontWeight: 500,
                ml: 2, // space between Submit/Edit and Cancel
                backgroundColor: "#1976d2",
                "&:hover": { backgroundColor: "#115293" },
              }}
            >
              Cancel
            </Button>
          </Grid>
        ))}
    </Grid>
  );
};

export default SubmitButton;
